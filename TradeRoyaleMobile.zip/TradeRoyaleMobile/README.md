Mobile App for TradeRoyale
